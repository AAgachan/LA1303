using Microsoft.VisualStudio.TestTools.UnitTesting;
using Cäsarverschlüsselung; 
namespace MS_Cäsarverschlüsselung
{
    [TestClass]
    public class MS_Cäsarverschlüsselung
    {
        // User Story 1: Verschlüsselungsfunktion testen
        [TestMethod]
        public void TestEncryptFunction()
        {
            // Arrange
            var originalEncryptedTextsCount = Program.encryptedTexts.Count;
            Console.SetIn(new StringReader("1\nHELLO\n3"));

            // Act
            Program.EncryptText();

            // Assert
            Assert.AreEqual(originalEncryptedTextsCount + 1, Program.encryptedTexts.Count);
        }

        // User Story 2: Anpassungsmöglichkeit des Verschiebewerts testen
        [TestMethod]
        public void TestAdjustEncryptionKey()
        {
            // Arrange
            Console.SetIn(new StringReader("1\nHELLO\n5"));
            int originalEncryptedTextsCount = Program.encryptedTexts.Count;

            // Act
            Program.EncryptText();

            // Assert
            Assert.AreEqual(originalEncryptedTextsCount + 1, Program.encryptedTexts.Count);
        }

        // User Story 3: Entschlüsselungsfunktion testen
        [TestMethod]
        public void TestDecryptMultipleTexts()
        {
            // Arrange
            Program.encryptedTexts = new List<KeyValuePair<string, int>>
            {
                new KeyValuePair<string, int>("KHOOR", 3)
            };
            
            Console.SetOut(new StringWriter());

            // Act
            Program.DecryptText();
            var consoleOutput = Console.Out.ToString().Trim();

            // Assert
            Assert.IsTrue(consoleOutput.Contains("HELLO"));
        }
    }
}
