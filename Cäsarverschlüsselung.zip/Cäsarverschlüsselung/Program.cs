﻿namespace Cäsarverschlüsselung
{
    public class Program
    {
        public static List<KeyValuePair<string, int>> encryptedTexts = new List<KeyValuePair<string, int>>();

        public static void Main(string[] args)
        {
            while (true)
            {
                
                Console.WriteLine("Do you want to Encrypt [1], Decrypt [2], or Exit [3]?");
                int choice;
                while (!int.TryParse(Console.ReadLine(), out choice) || (choice != 1 && choice != 2 && choice != 3))
                {
                    Console.WriteLine("Bitte wählen Sie eine Nummer von 1-3. Wählen Sie 1 für verschlüsseln des Textes, 2 für entschlüsseln des Textes, 3 zum Beenden von Programm.");
                }
                switch (choice)
                {
                    case 1:
                        EncryptText();
                        break;
                    case 2:
                        DecryptText();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                }
            }
        }

        public static void EncryptText()
        {
            int displace = displacement();
            Console.WriteLine("Please enter the text:");
            string input = Console.ReadLine().ToLower();

            string output = CaesarCipherOperation(input, displace);
            encryptedTexts.Add(new KeyValuePair<string, int>(output, displace));
            Console.WriteLine("Encrypted text: " + output);
        }

        public static void DecryptText()
        {
            if (encryptedTexts.Count == 0)
            {
                Console.WriteLine("No encrypted texts available.");
                return;
            }

            for (int i = 0; i < encryptedTexts.Count; i++)
            {
                var pair = encryptedTexts[i];
                string decrypted = CaesarCipherOperation(pair.Key, -pair.Value);
                Console.WriteLine($"Decrypted text {i + 1}: {decrypted}");
            }
        }

        public static int displacement()
        {   
                Console.Write("Enter a number between 1 and 25 to shift the encrypted Text: ");
                int displace;
                while (!int.TryParse(Console.ReadLine(), out displace) || (displace != 1 && displace != 2 && displace != 3 && displace != 4 && displace != 5 && displace != 6 && displace != 7 && displace != 8 && displace != 9 && displace != 10 && displace != 11 && displace != 12 && displace != 13 && displace != 14 && displace != 15 && displace != 16 && displace != 17 && displace != 18 && displace != 19 && displace != 20 && displace != 21 && displace != 22 && displace != 23 && displace != 24 && displace != 25))
                {
                    Console.WriteLine("Bitte wählen Sie eine Nummer von 1-25.");
                }
     
            return displace;
        }

        public static string CaesarCipherOperation(string text, int displace)
        {
            string output = "";
            foreach (char character in text)
            {
                output += EncryptCharacter(character, displace);
            }
            return output;
        }

        public static char EncryptCharacter(char character, int displace)
        {
            if (!char.IsLetter(character))
            {
                return character;
            }

            char baseChar = char.IsUpper(character) ? 'A' : 'a';
            return (char)(((character - baseChar + displace + 26) % 26) + baseChar);
        }
    }

}
